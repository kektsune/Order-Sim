README for Form-Decor

CONTROLS:
"Customer Order" groupbox - Randomly generates food options that the customer ordered for the user to match

"Menu" groupbox - Lists the different meals, sides, and drinks, providing the price on the side for the user to calculate

"Total Money Earned" groupbox - Shows the amount of money that the user earns (whether they interpret it as their own personal money or business money is up to them) and shows their increment/decrement per order they get right or wrong

"Timer" groupbox - Shows the time remaining in the current order

"Orders Progress" groupbox - Shows the amount of orders that the user completed

"Order" groupbox - Shows the different radio buttons for Dine-in, Takeout, and Delivery, the user can only select one variant that matches the customer's order

"Select ordered meal" dropdown/combobox - Lets the user select the matching meal from the dropdown list to the customer order

"Select ordered side" dropdown/combobox - Lets the user select the matching side from the dropdown list to the customer order

"Select ordered drink" dropdown/combobox - Lets the user select the matching drink from the dropdown list to the customer order

"Enter the overall price" textbox - Lets the user enter the total cost of the meal that they've calculated

"Enter Order" button - Lets the user enter all of their selected options. If it's wrong there will be a correction error that shows what you did wrong and you lose money. If it's right, you earn money. In either case your order is submitted to the data grid view in the center. Selected options are reset/refreshed.

Data grid view (center box) - Stores the user's input of the order history and checks if they were correct or incorrect. 

CREDITS:
Program made by Kektsune in Visual Basic

DOWNLOAD / RELEASES:
In case you can’t find the download or want older versions:  
Order-Sim v1.0.0 Release: https://github.com/kektsune/Order-Sim
